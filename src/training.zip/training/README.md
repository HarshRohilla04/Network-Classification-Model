# Training & Model Code

This folder contains the model definition and training pipeline (originally SAMSUNG_HACKATHON).
