#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pcap_to_csv.py
Convert a .pcap into a CSV with lightweight per-packet features compatible with your LightGBM model.
No tshark/pyshark required (uses scapy). Works offline on macOS/Linux/Windows.

Usage:
  python pcap_to_csv.py --pcap capture.pcap --out packets.csv

Install deps (once):
  pip install scapy==2.5.0 pandas==2.2.2 numpy==2.0.2 tqdm==4.66.5
"""
import argparse, time, os, sys
import pandas as pd
import numpy as np
from tqdm import tqdm
from scapy.all import PcapReader, IP, IPv6, TCP, UDP, DNS, Raw, ICMP

FEATURES = [
    "Length","info_len","digits_in_info","delta_time","src_port","dst_port",
    "flag_SYN","flag_ACK","flag_PSH","flag_RST","flag_FIN","flag_URG","flag_ECE","flag_CWR",
    "has_http","has_tls","has_quic","has_dns","has_get","has_post",
    "has_rtp","has_rtcp","has_rtsp","has_ssl","has_video","has_audio","has_application_data",
    "Protocol"
]
PROTOCOL_MAP = {"TCP":6,"UDP":17,"ICMP":1,"OTHER":0}

def extract_payload(raw_bytes: bytes) -> str:
    if not raw_bytes: return ""
    try: return raw_bytes.decode("latin-1", errors="ignore")
    except Exception: return ""

class FeatureExtractor:
    def __init__(self):
        self.prev_ts = None
    def delta(self, ts: float) -> float:
        if self.prev_ts is None:
            self.prev_ts = ts
            return 0.0
        d = max(0.0, ts - self.prev_ts)
        self.prev_ts = ts
        return d
    def from_packet(self, pkt):
        length = len(bytes(pkt)) if pkt is not None else 0
        ts = float(getattr(pkt, "time", time.time()))
        delta_time = self.delta(ts)

        l3 = "OTHER"
        src_port = 0; dst_port = 0
        flags = {"S":0,"A":0,"P":0,"R":0,"F":0,"U":0,"E":0,"C":0}
        has_http = has_tls = has_quic = has_dns = 0
        has_get = has_post = 0
        has_rtp = has_rtcp = has_rtsp = 0
        has_ssl = has_video = has_audio = has_application_data = 0
        info_len = 0
        digits_in_info = 0
        payload_txt = ""

        if pkt.haslayer(IP) or pkt.haslayer(IPv6):
            l3 = "TCP" if pkt.haslayer(TCP) else "UDP" if pkt.haslayer(UDP) else "ICMP" if pkt.haslayer(ICMP) else "OTHER"

        if pkt.haslayer(TCP):
            t = pkt[TCP]
            src_port, dst_port = int(t.sport), int(t.dport)
            flags["S"] = 1 if t.flags & 0x02 else 0
            flags["A"] = 1 if t.flags & 0x10 else 0
            flags["P"] = 1 if t.flags & 0x08 else 0
            flags["R"] = 1 if t.flags & 0x04 else 0
            flags["F"] = 1 if t.flags & 0x01 else 0
            flags["U"] = 1 if t.flags & 0x20 else 0
            flags["E"] = 1 if t.flags & 0x40 else 0
            flags["C"] = 1 if t.flags & 0x80 else 0
        elif pkt.haslayer(UDP):
            u = pkt[UDP]
            src_port, dst_port = int(u.sport), int(u.dport)

        if pkt.haslayer(DNS):
            has_dns = 1

        if pkt.haslayer(Raw):
            raw_bytes = bytes(pkt[Raw].load)
            payload_txt = extract_payload(raw_bytes)
            info_len = len(payload_txt)
            digits_in_info = sum(ch.isdigit() for ch in payload_txt)
            txt = payload_txt.upper()
            if "HTTP/" in txt or "HOST:" in txt or txt.startswith("GET ") or txt.startswith("POST "):
                has_http = 1
                if txt.startswith("GET "): has_get = 1
                if txt.startswith("POST "): has_post = 1
            if "RTSP/" in txt: has_rtsp = 1
            if "RTP" in txt and "PAYLOAD" in txt: has_rtp = 1
            if "RTCP" in txt: has_rtcp = 1
            if "TLS" in txt: has_tls = 1
            if "SSL" in txt: has_ssl = 1
            if "QUIC" in txt: has_quic = 1
            if "VIDEO" in txt: has_video = 1
            if "AUDIO" in txt: has_audio = 1
            if "APPLICATION DATA" in txt or "APP-DATA" in txt: has_application_data = 1

        # Heuristic QUIC by UDP/443 if payload didn't tell us
        if has_quic == 0 and pkt.haslayer(UDP) and (dst_port in (443,80) or src_port in (443,80)) and payload_txt == "":
            has_quic = 1

        return {
            "Length": length,
            "info_len": info_len,
            "digits_in_info": digits_in_info,
            "delta_time": float(delta_time),
            "src_port": src_port,
            "dst_port": dst_port,
            "flag_SYN": flags["S"],
            "flag_ACK": flags["A"],
            "flag_PSH": flags["P"],
            "flag_RST": flags["R"],
            "flag_FIN": flags["F"],
            "flag_URG": flags["U"],
            "flag_ECE": flags["E"],
            "flag_CWR": flags["C"],
            "has_http": has_http,
            "has_tls": has_tls,
            "has_quic": has_quic,
            "has_dns": has_dns,
            "has_get": has_get,
            "has_post": has_post,
            "has_rtp": has_rtp,
            "has_rtcp": has_rtcp,
            "has_rtsp": has_rtsp,
            "has_ssl": has_ssl,
            "has_video": has_video,
            "has_audio": has_audio,
            "has_application_data": has_application_data,
            "Protocol": PROTOCOL_MAP.get(l3, 0),
        }

def convert(pcap_path: str, out_csv: str, limit: int = 0):
    fe = FeatureExtractor()
    rows = []
    count = 0
    with PcapReader(pcap_path) as reader:
        for pkt in tqdm(reader, desc="Parsing"):
            try:
                row = fe.from_packet(pkt)
                rows.append(row)
                count += 1
                if limit and count >= limit:
                    break
                if len(rows) >= 5000:
                    df = pd.DataFrame(rows, columns=FEATURES)
                    df.to_csv(out_csv, mode="a", index=False, header=not os.path.exists(out_csv))
                    rows.clear()
            except Exception:
                # Skip malformed packets
                continue
    if rows:
        df = pd.DataFrame(rows, columns=FEATURES)
        df.to_csv(out_csv, mode="a", index=False, header=not os.path.exists(out_csv))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pcap", required=True, help="Input pcap file")
    ap.add_argument("--out", required=True, help="Output CSV file")
    ap.add_argument("--limit", type=int, default=0, help="Optional: limit number of packets")
    args = ap.parse_args()
    convert(args.pcap, args.out, args.limit)

if __name__ == "__main__":
    main()
