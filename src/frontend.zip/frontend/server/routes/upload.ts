import type { RequestHandler } from "express";
import multer from "multer";
import os from "os";
import path from "path";
import { promises as fs } from "fs";
import { execFile } from "child_process";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 },
});

const BASE_URL = "https://karan0301-network-traffic-api.hf.space";

function pickEndpoint(filename: string, mimetype?: string) {
  const name = filename.toLowerCase();
  const isCsv = name.endsWith(".csv") || (mimetype ?? "").includes("csv");
  const isPcap =
    name.endsWith(".pcap") ||
    name.endsWith(".pcapng") ||
    (mimetype ?? "").includes("pcap");
  if (isCsv) return "/predict_csv";
  if (isPcap) return "/predict_pcap"; // best-effort if backend supports
  return "/predict_csv";
}

async function attemptMultipart(
  target: string,
  buf: Buffer,
  name: string,
  type: string,
  fieldName: string,
) {
  const form = new FormData();
  const blob = new Blob([buf], { type: type || "text/csv" });
  form.append(fieldName, blob, name);
  return fetch(target, {
    method: "POST",
    body: form as any,
    headers: { "Cache-Control": "no-cache" },
  });
}

async function convertPcapToCsvBuffer(
  buf: Buffer,
  originalName: string,
): Promise<Buffer> {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "pcap-"));
  const pcapPath = path.join(tmpDir, originalName || "upload.pcap");
  const csvPath = path.join(tmpDir, "converted.csv");
  await fs.writeFile(pcapPath, buf);
  const scriptPath = path.resolve("./pcap_to_csv.py");
  await new Promise<void>((resolve, reject) => {
    execFile(
      "python3",
      [scriptPath, "--pcap", pcapPath, "--out", csvPath],
      { cwd: process.cwd() },
      (err, _stdout, stderr) => {
        if (err) return reject(new Error(stderr || err.message));
        resolve();
      },
    );
  });
  const csvBuf = await fs.readFile(csvPath);
  fs.unlink(pcapPath).catch(() => {});
  fs.unlink(csvPath).catch(() => {});
  fs.rmdir(tmpDir).catch(() => {});
  return csvBuf;
}

export const handlePredictUploadMiddleware = upload.single("file");

export const handlePredictUpload: RequestHandler = async (req, res) => {
  try {
    const file = (req as any).file as Express.Multer.File | undefined;
    if (!file) {
      return res
        .status(400)
        .json({
          error:
            "No file uploaded. Use form field 'file' with .csv or .pcap/.pcapng.",
        });
    }

    const isPcap =
      /\.(pcap|pcapng)$/i.test(file.originalname) ||
      (file.mimetype || "").includes("pcap");

    if (isPcap) {
      return res.status(400).json({ error: "PCAP upload is not supported in this environment. Please upload CSV instead." });
      try {
        const csvBuf = await convertPcapToCsvBuffer(
          file.buffer,
          file.originalname,
        );
        const form = new FormData();
        form.append(
          "file",
          new Blob([csvBuf], { type: "text/csv" }),
          "converted.csv",
        );
        const resp = await fetch(`${BASE_URL}/predict_csv`, {
          method: "POST",
          body: form as any,
        });
        const ct = resp.headers.get("content-type") || "";
        if (!resp.ok) {
          const errText = await resp.text().catch(() => "");
          return res
            .status(502)
            .json({
              error: "Upstream prediction API error (after convert)",
              status: resp.status,
              details: errText,
            });
        }
        if (ct.includes("application/json")) {
          const data = await resp.json();
          return res.json({
            source: "huggingface-space",
            endpoint: "/predict_csv",
            data,
            from: "pcap-converted",
          });
        } else {
          const text = await resp.text();
          return res.json({
            source: "huggingface-space",
            endpoint: "/predict_csv",
            data: text,
            from: "pcap-converted",
          });
        }
      } catch (e: any) {
        const target = `${BASE_URL}/predict_pcap`;
        const candidates = ["file", "pcap", "data"];
        let lastErrText = String(e?.message || e);
        for (const field of candidates) {
          try {
            const resp = await attemptMultipart(
              target,
              file.buffer,
              file.originalname,
              file.mimetype,
              field,
            );
            const ct = resp.headers.get("content-type") || "";
            if (!resp.ok) {
              lastErrText = await resp.text().catch(() => lastErrText);
              continue;
            }
            if (ct.includes("application/json")) {
              const data = await resp.json();
              return res.json({
                source: "huggingface-space",
                endpoint: "/predict_pcap",
                data,
                field_used: field,
              });
            } else {
              const text = await resp.text();
              return res.json({
                source: "huggingface-space",
                endpoint: "/predict_pcap",
                data: text,
                field_used: field,
              });
            }
          } catch (ee: any) {
            lastErrText = String(ee?.message || ee);
            continue;
          }
        }
        return res
          .status(500)
          .json({
            error: "PCAP conversion failed and direct predict_pcap unavailable",
            details: lastErrText,
          });
      }
    }

    const endpoint = "/predict_csv";
    const target = `${BASE_URL}${endpoint}`;
    const candidates = ["file", "csv", "csv_file", "data"];
    let lastErrText = "";
    for (const field of candidates) {
      try {
        const resp = await attemptMultipart(
          target,
          file.buffer,
          file.originalname,
          file.mimetype,
          field,
        );
        const ct = resp.headers.get("content-type") || "";
        if (!resp.ok) {
          lastErrText = await resp.text().catch(() => "");
          continue;
        }
        if (ct.includes("application/json")) {
          const data = await resp.json();
          return res.json({
            source: "huggingface-space",
            endpoint,
            data,
            field_used: field,
          });
        } else {
          const text = await resp.text();
          return res.json({
            source: "huggingface-space",
            endpoint,
            data: text,
            field_used: field,
          });
        }
      } catch (e: any) {
        lastErrText = String(e?.message || e);
        continue;
      }
    }

    return res
      .status(502)
      .json({
        error: "Upstream prediction API error",
        details: lastErrText || "All attempts failed",
        tried_fields: candidates,
      });
  } catch (err: any) {
    console.error("Prediction upload error:", err);
    return res
      .status(500)
      .json({
        error: "Failed to process file for prediction",
        details: String(err?.message || err),
      });
  }
};

export const handlePredictHealth: RequestHandler = async (_req, res) => {
  try {
    const sampleCsv = "a,b\n1,2\n";
    const target = `${BASE_URL}/predict_csv`;
    const form = new FormData();
    form.append(
      "file",
      new Blob([sampleCsv], { type: "text/csv" }),
      "sample.csv",
    );
    const resp = await fetch(target, { method: "POST", body: form as any });
    const ct = resp.headers.get("content-type") || "";
    const ok = resp.ok;
    const body = ct.includes("application/json")
      ? await resp.json().catch(() => null)
      : await resp.text().catch(() => "");
    return res.json({
      ok,
      status: resp.status,
      content_type: ct,
      body: body?.slice ? body.slice(0, 200) : body,
    });
  } catch (e: any) {
    return res.status(500).json({ ok: false, error: String(e?.message || e) });
  }
};
