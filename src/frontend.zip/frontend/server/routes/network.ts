import { RequestHandler } from "express";
import {
  StartCaptureRequest,
  StartCaptureResponse,
  StopCaptureRequest,
  StopCaptureResponse,
  GetModelStatusResponse,
  GetRealtimeDataResponse,
  CaptureSession,
  NetworkPacket,
  ClassificationResult,
  NetworkStats,
  ModelStatus,
  FeatureSelection,
} from "@shared/api";

// In-memory storage for demo purposes
// In production, use Redis or database
let activeSessions: Map<string, CaptureSession> = new Map();
let recentPackets: NetworkPacket[] = [];
let recentClassifications: ClassificationResult[] = [];
let currentStats: NetworkStats = {
  total_packets: 0,
  packets_per_second: 0,
  bytes_per_second: 0,
  classification_breakdown: {},
  threat_level_breakdown: {},
  top_source_ips: [],
  top_destination_ips: [],
  protocol_breakdown: {},
};

// Mock model status
const modelStatus: ModelStatus = {
  loaded: true,
  model_name: "Network Intrusion Detection v2.1",
  version: "2.1.0",
  last_updated: Date.now() - 86400000, // 24 hours ago
  accuracy: 0.94,
  feature_count: 47,
  supported_classes: [
    "Normal",
    "DDoS",
    "Port Scan",
    "Malware",
    "Brute Force",
    "SQL Injection",
  ],
  processing_time_avg_ms: 12,
};

const featureSelection: FeatureSelection = {
  selected_features: [
    "packet_size",
    "flow_duration",
    "packets_per_second",
    "bytes_per_second",
    "protocol",
    "port_scan_ratio",
    "connection_state",
    "service_type",
    "flag_count",
    "urgent_count",
    "hot_count",
    "num_failed_logins",
    "logged_in",
    "num_compromised",
    "root_shell",
    "su_attempted",
    "num_root",
    "num_file_creations",
    "num_shells",
    "num_access_files",
    "is_host_login",
    "is_guest_login",
    "count",
    "srv_count",
    "serror_rate",
    "srv_serror_rate",
    "rerror_rate",
    "srv_rerror_rate",
    "same_srv_rate",
    "diff_srv_rate",
    "srv_diff_host_rate",
    "dst_host_count",
    "dst_host_srv_count",
    "dst_host_same_srv_rate",
    "dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate",
    "dst_host_srv_diff_host_rate",
    "dst_host_serror_rate",
    "dst_host_srv_serror_rate",
    "dst_host_rerror_rate",
    "dst_host_srv_rerror_rate",
    "tcp_flag_combination",
    "header_length",
    "window_size",
    "payload_entropy",
    "inter_arrival_time",
    "burst_rate",
  ],
  dropped_features: [
    "raw_packet_data",
    "checksum",
    "timestamp_micro",
    "session_id_internal",
    "raw_flags",
    "packet_id_sequence",
    "network_delay",
    "jitter_variance",
  ],
  total_features: 55,
  selection_method: "Random Forest Feature Importance + Correlation Analysis",
  importance_scores: {
    packet_size: 0.12,
    flow_duration: 0.09,
    packets_per_second: 0.11,
    bytes_per_second: 0.08,
    protocol: 0.07,
  },
};

// Simulate real-time packet generation
function generateMockPacket(): NetworkPacket {
  const protocols = ["TCP", "UDP", "ICMP"];
  const sourceIPs = [
    "192.168.1.100",
    "10.0.0.45",
    "172.16.0.12",
    "203.0.113.5",
  ];
  const destIPs = ["192.168.1.1", "8.8.8.8", "1.1.1.1", "192.168.1.50"];

  return {
    id: `pkt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now(),
    source_ip: sourceIPs[Math.floor(Math.random() * sourceIPs.length)],
    destination_ip: destIPs[Math.floor(Math.random() * destIPs.length)],
    source_port: Math.floor(Math.random() * 65535),
    destination_port: Math.floor(Math.random() * 65535),
    protocol: protocols[Math.floor(Math.random() * protocols.length)],
    packet_size: Math.floor(Math.random() * 1500) + 64,
    flags: ["SYN", "ACK"],
    payload_size: Math.floor(Math.random() * 1400),
    flow_duration: Math.random() * 1000,
    packets_per_second: Math.random() * 100,
    bytes_per_second: Math.random() * 10000,
  };
}

function generateMockClassification(
  packet: NetworkPacket,
): ClassificationResult {
  const classes = ["Normal", "DDoS", "Port Scan", "Malware", "Brute Force"];
  const threatLevels = ["low", "medium", "high", "critical"] as const;
  const classification = classes[Math.floor(Math.random() * classes.length)];

  return {
    packet_id: packet.id,
    classification,
    confidence: 0.7 + Math.random() * 0.3,
    timestamp: Date.now(),
    processing_time_ms: 8 + Math.random() * 20,
    features_used: featureSelection.selected_features.slice(0, 10),
    threat_level:
      classification === "Normal"
        ? "low"
        : threatLevels[Math.floor(Math.random() * threatLevels.length)],
    details: {
      predicted_class: classification,
      probability_distribution: {
        Normal: Math.random() * 0.3,
        DDoS: Math.random() * 0.3,
        "Port Scan": Math.random() * 0.3,
        Malware: Math.random() * 0.3,
        "Brute Force": Math.random() * 0.3,
      },
    },
  };
}

export const handleStartCapture: RequestHandler = (req, res) => {
  try {
    const request = req.body as StartCaptureRequest;
    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const session: CaptureSession = {
      id: sessionId,
      status: "starting",
      interface: request.interface || "eth0",
      packets_captured: 0,
      packets_classified: 0,
    };

    activeSessions.set(sessionId, session);

    // Simulate starting capture
    setTimeout(() => {
      const updatedSession = activeSessions.get(sessionId);
      if (updatedSession) {
        updatedSession.status = "capturing";
        updatedSession.start_time = Date.now();
        activeSessions.set(sessionId, updatedSession);
      }
    }, 1000);

    const response: StartCaptureResponse = {
      session_id: sessionId,
      status: "starting",
      message: `Started packet capture on interface ${request.interface || "eth0"}`,
    };

    res.json(response);
  } catch (error) {
    console.error("Error starting capture:", error);
    res.status(500).json({ error: "Failed to start packet capture" });
  }
};

export const handleStopCapture: RequestHandler = (req, res) => {
  try {
    const request = req.body as StopCaptureRequest;
    const session = activeSessions.get(request.session_id);

    if (!session) {
      return res.status(404).json({ error: "Session not found" });
    }

    session.status = "stopping";
    activeSessions.set(request.session_id, session);

    // Simulate stopping capture
    setTimeout(() => {
      activeSessions.delete(request.session_id);
    }, 500);

    const response: StopCaptureResponse = {
      session_id: request.session_id,
      status: "stopped",
      final_stats: currentStats,
    };

    res.json(response);
  } catch (error) {
    console.error("Error stopping capture:", error);
    res.status(500).json({ error: "Failed to stop packet capture" });
  }
};

export const handleGetModelStatus: RequestHandler = (_req, res) => {
  try {
    const response: GetModelStatusResponse = {
      model: modelStatus,
      feature_selection: featureSelection,
    };
    res.json(response);
  } catch (error) {
    console.error("Error getting model status:", error);
    res.status(500).json({ error: "Failed to get model status" });
  }
};

export const handleGetRealtimeData: RequestHandler = (req, res) => {
  try {
    const sessionId = req.query.session_id as string;
    const session = sessionId ? activeSessions.get(sessionId) : null;

    // Generate mock real-time data if session is active
    if (session && session.status === "capturing") {
      // Generate new packets
      const newPackets = Array.from(
        { length: Math.floor(Math.random() * 5) + 1 },
        generateMockPacket,
      );
      recentPackets.push(...newPackets);

      // Generate classifications for new packets
      const newClassifications = newPackets.map(generateMockClassification);
      recentClassifications.push(...newClassifications);

      // Update session stats
      session.packets_captured += newPackets.length;
      session.packets_classified += newClassifications.length;

      // Keep only recent data (last 100 items)
      recentPackets = recentPackets.slice(-100);
      recentClassifications = recentClassifications.slice(-100);

      // Update stats
      currentStats.total_packets += newPackets.length;
      currentStats.packets_per_second = Math.floor(Math.random() * 50) + 10;
      currentStats.bytes_per_second = Math.floor(Math.random() * 50000) + 5000;

      // Update classification breakdown
      newClassifications.forEach((c) => {
        currentStats.classification_breakdown[c.classification] =
          (currentStats.classification_breakdown[c.classification] || 0) + 1;
        currentStats.threat_level_breakdown[c.threat_level] =
          (currentStats.threat_level_breakdown[c.threat_level] || 0) + 1;
      });
    }

    const response: GetRealtimeDataResponse = {
      session: session || {
        id: "",
        status: "idle",
        interface: "",
        packets_captured: 0,
        packets_classified: 0,
      },
      recent_packets: recentPackets.slice(-20), // Last 20 packets
      recent_classifications: recentClassifications.slice(-20), // Last 20 classifications
      stats: currentStats,
    };

    res.json(response);
  } catch (error) {
    console.error("Error getting realtime data:", error);
    res.status(500).json({ error: "Failed to get realtime data" });
  }
};
