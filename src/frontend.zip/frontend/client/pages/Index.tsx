import * as React from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Shield,
  AlertCircle,
  Network,
  Target,
  UploadCloud,
  Trash2,
  Download,
  Copy,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { GetModelStatusResponse } from "@shared/api";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart";
import {
  PieChart as RePieChart,
  Pie,
  Cell,
  BarChart as ReBarChart,
  Bar,
  XAxis,
  YAxis,
} from "recharts";

export default function Index() {
  const [modelStatus, setModelStatus] =
    React.useState<GetModelStatusResponse | null>(null);
  const [file, setFile] = React.useState<File | null>(null);
  const [isUploading, setIsUploading] = React.useState(false);
  const [result, setResult] = React.useState<any>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [csvHeaders, setCsvHeaders] = React.useState<string[] | null>(null);
  const [csvRows, setCsvRows] = React.useState<string[][]>([]);
  const [labelCounts, setLabelCounts] = React.useState<Record<string, number>>(
    {},
  );
  const [csvText, setCsvText] = React.useState<string>("");
  const [filterText, setFilterText] = React.useState("");
  const [topN, setTopN] = React.useState<number>(8);

  React.useEffect(() => {
    fetchModelStatus();
  }, []);

  const fetchModelStatus = async () => {
    try {
      const response = await fetch("/api/network/model-status");
      const data = (await response.json()) as GetModelStatusResponse;
      setModelStatus(data);
    } catch (error) {
      console.error("Error fetching model status:", error);
    }
  };

  const onUpload = async () => {
    if (!file) return;
    setIsUploading(true);
    setError(null);
    setResult(null);
    setCsvHeaders(null);
    setCsvRows([]);
    setLabelCounts({});
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/network/predict-file", {
        method: "POST",
        body: form,
        headers: { "Cache-Control": "no-cache" },
      });
      const contentType = res.headers.get("content-type") || "";
      let data: any = null;
      if (!res.bodyUsed) {
        const raw = await res.text();
        data = raw;
        if (contentType.includes("application/json")) {
          try {
            data = JSON.parse(raw);
          } catch {
            /* keep text */
          }
        }
      }
      if (!res.ok) {
        const msg =
          typeof data === "string"
            ? data
            : data?.error || data?.details || `HTTP ${res.status}`;
        setError(msg);
      } else {
        setResult(data);
        const payload = (data as any)?.data;
        let parsedCsv: string | null = null;
        if (typeof payload === "string") parsedCsv = payload;
        else if (
          payload &&
          typeof payload === "object" &&
          typeof (payload as any).csv === "string"
        )
          parsedCsv = (payload as any).csv;
        else if (
          Array.isArray(payload) &&
          payload.every((x: any) => typeof x === "string")
        )
          parsedCsv = (payload as string[]).join("\n");
        if (parsedCsv) {
          setCsvText(parsedCsv);
          const lines = parsedCsv
            .split(/\r?\n/)
            .filter((l: string) => l.trim().length > 0);
          if (lines.length > 0) {
            const headers = lines[0].split(",");
            const rows = lines.slice(1).map((l: string) => l.split(","));
            setCsvHeaders(headers);
            setCsvRows(rows);
            const labelIdx = headers.findIndex(
              (h) => h.trim().toLowerCase() === "predicted_label",
            );
            if (labelIdx >= 0) {
              const counts: Record<string, number> = {};
              for (const r of rows) {
                const label = (r[labelIdx] || "").trim();
                if (!label) continue;
                counts[label] = (counts[label] || 0) + 1;
              }
              setLabelCounts(counts);
            }
          }
        }
      }
    } catch (e: any) {
      setError(String(e?.message || e));
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  NetGuard AI
                </h1>
                <p className="text-sm text-muted-foreground">
                  Upload CSV/PCAP for classification
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Badge
                variant={modelStatus?.model.loaded ? "default" : "destructive"}
                className="flex items-center space-x-1"
              >
                <div
                  className={`w-2 h-2 rounded-full ${modelStatus?.model.loaded ? "bg-security-safe animate-pulse" : "bg-destructive"}`}
                />
                <span>
                  {modelStatus?.model.loaded ? "Model Online" : "Model Offline"}
                </span>
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-3 space-y-6">
            {modelStatus && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>Model Info</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <div className="text-sm font-medium">
                      {modelStatus.model.model_name}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      v{modelStatus.model.version}
                    </div>
                  </div>
                  {modelStatus.model.accuracy && (
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Accuracy</span>
                        <span>
                          {(modelStatus.model.accuracy * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress
                        value={modelStatus.model.accuracy * 100}
                        className="h-2"
                      />
                    </div>
                  )}
                  <div className="text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Features:</span>
                      <span>
                        {modelStatus.feature_selection.selected_features.length}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Classes:</span>
                      <span>{modelStatus.model.supported_classes.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Avg Time:</span>
                      <span>{modelStatus.model.processing_time_avg_ms}ms</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {csvRows.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-2">
                    <AlertCircle className="h-5 w-5" />
                    <span>Dataset Summary</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Rows</span>
                    <span className="font-mono">{csvRows.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Unique Labels</span>
                    <span className="font-mono">
                      {Object.keys(labelCounts).length}
                    </span>
                  </div>
                  {result?.endpoint && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Endpoint</span>
                      <Badge variant="outline">{result.endpoint}</Badge>
                    </div>
                  )}
                  {Object.keys(labelCounts).length > 0 ? (
                    <div className="space-y-2">
                      <div className="text-xs text-muted-foreground">
                        Top Labels
                      </div>
                      {Object.entries(labelCounts)
                        .sort((a, b) => b[1] - a[1])
                        .slice(0, 5)
                        .map(([label, count]) => {
                          const pct = Math.round(
                            (count / csvRows.length) * 100,
                          );
                          return (
                            <div key={label} className="space-y-1">
                              <div className="flex justify-between text-xs">
                                <span
                                  className="truncate max-w-[9rem]"
                                  title={label}
                                >
                                  {label}
                                </span>
                                <span className="font-mono">
                                  {count} · {pct}%
                                </span>
                              </div>
                              <Progress value={pct} className="h-1.5" />
                            </div>
                          );
                        })}
                    </div>
                  ) : (
                    <div className="text-xs text-muted-foreground">
                      No predicted_label column found in the CSV.
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          <div className="lg:col-span-9 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Network className="h-5 w-5" />
                  <span>Upload CSV</span>
                </CardTitle>
                <CardDescription>
                  Select a .csv file to classify
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 relative">
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const f = e.dataTransfer.files?.[0];
                    if (f) {
                      if (!f.name.toLowerCase().endsWith(".csv")) {
                        setError("Only CSV is supported in this environment.");
                      } else {
                        setFile(f);
                      }
                    }
                  }}
                  className="w-full border-2 border-dashed border-border rounded-lg p-6 text-center hover:bg-card/40 transition-colors relative"
                >
                  <div className="flex flex-col items-center gap-2 text-sm text-muted-foreground pointer-events-none">
                    <UploadCloud className="h-5 w-5" />
                    <div>Drag & drop your file here</div>
                    <div className="text-xs">or click to select</div>
                  </div>
                  <input
                    type="file"
                    accept=".csv,text/csv,application/vnd.ms-excel"
                    onChange={(e) => {
                    const f = e.target.files?.[0] || null;
                    if (f && !f.name.toLowerCase().endsWith(".csv")) {
                      setError("Only CSV is supported in this environment.");
                      setFile(null);
                    } else {
                      setFile(f);
                    }
                  }}
                    className="absolute opacity-0 inset-0 cursor-pointer"
                    aria-label="Upload file"
                  />
                </div>
                {file && (
                  <div className="text-xs text-muted-foreground">
                    Selected:{" "}
                    <span className="font-mono text-foreground">
                      {file.name}
                    </span>{" "}
                    ({(file.size / 1024).toFixed(1)} KB)
                  </div>
                )}
                <div className="flex gap-2">
                  <Button
                    onClick={onUpload}
                    disabled={
                      !file || isUploading || !modelStatus?.model.loaded
                    }
                    className="flex-1"
                  >
                    {isUploading ? "Uploading..." : "Run Classification"}
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => {
                      setFile(null);
                      setResult(null);
                      setCsvHeaders(null);
                      setCsvRows([]);
                      setLabelCounts({});
                      setCsvText("");
                      setFilterText("");
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                {error && (
                  <div className="text-sm text-destructive">{error}</div>
                )}
              </CardContent>
            </Card>

            {result && (
              <>
                {csvHeaders && csvRows.length > 0 && (
                  <>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center space-x-2">
                            <AlertCircle className="h-5 w-5" />
                            <span>Label Distribution</span>
                          </CardTitle>
                          <CardDescription>
                            Proportion of predicted labels
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <ChartContainer
                            config={Object.fromEntries(
                              Object.keys(labelCounts).map((k, i) => [
                                k,
                                {
                                  label: k,
                                  color: `hsl(${(i * 37) % 360} 82% 60%)`,
                                },
                              ]),
                            )}
                            className="h-72"
                          >
                            <RePieChart>
                              <Pie
                                data={Object.entries(labelCounts).map(
                                  ([name, value]) => ({ name, value }),
                                )}
                                dataKey="value"
                                nameKey="name"
                                outerRadius={110}
                              >
                                {Object.entries(labelCounts).map(
                                  ([name], i) => (
                                    <Cell
                                      key={name}
                                      fill={`hsl(${(i * 37) % 360} 82% 60%)`}
                                    />
                                  ),
                                )}
                              </Pie>
                              <ChartTooltip
                                content={<ChartTooltipContent nameKey="name" />}
                              />
                              <ChartLegend content={<ChartLegendContent />} />
                            </RePieChart>
                          </ChartContainer>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center space-x-2">
                            <AlertCircle className="h-5 w-5" />
                            <span>Top Labels</span>
                          </CardTitle>
                          <CardDescription>
                            Most frequent predictions
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center gap-3 mb-3">
                            <span className="text-xs text-muted-foreground">
                              Show
                            </span>
                            <Slider
                              value={[topN]}
                              min={3}
                              max={20}
                              step={1}
                              onValueChange={(v) => setTopN(v[0] || 8)}
                              className="w-40"
                            />
                            <span className="text-xs font-mono">{topN}</span>
                          </div>
                          <ChartContainer
                            config={{
                              count: {
                                label: "Count",
                                color: "hsl(var(--primary))",
                              },
                            }}
                            className="h-72"
                          >
                            <ReBarChart
                              data={Object.entries(labelCounts)
                                .map(([name, value]) => ({
                                  name,
                                  count: value,
                                }))
                                .sort((a, b) => b.count - a.count)
                                .slice(0, topN)}
                            >
                              <XAxis dataKey="name" hide />
                              <YAxis />
                              <Bar
                                dataKey="count"
                                fill="hsl(var(--primary))"
                                radius={[4, 4, 0, 0]}
                              />
                              <ChartTooltip
                                content={<ChartTooltipContent nameKey="name" />}
                              />
                            </ReBarChart>
                          </ChartContainer>
                        </CardContent>
                      </Card>
                    </div>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <AlertCircle className="h-5 w-5" /> Predictions Table
                        </CardTitle>
                        <CardDescription>
                          Filter and explore the first 100 rows
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Input
                            placeholder="Filter by label..."
                            value={filterText}
                            onChange={(e) => setFilterText(e.target.value)}
                            className="max-w-sm"
                          />
                          <Button
                            variant="secondary"
                            size="sm"
                            onClick={() => setFilterText("")}
                          >
                            Clear
                          </Button>
                          <div className="ml-auto flex gap-2">
                            {csvText && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  const blob = new Blob([csvText], {
                                    type: "text/csv",
                                  });
                                  const url = URL.createObjectURL(blob);
                                  const a = document.createElement("a");
                                  a.href = url;
                                  a.download = "predictions.csv";
                                  a.click();
                                  URL.revokeObjectURL(url);
                                }}
                              >
                                <Download className="h-4 w-4 mr-1" />
                                CSV
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                navigator.clipboard.writeText(
                                  JSON.stringify(result, null, 2),
                                )
                              }
                            >
                              <Copy className="h-4 w-4 mr-1" />
                              JSON
                            </Button>
                          </div>
                        </div>
                        <div className="overflow-auto border border-border rounded">
                          <table className="min-w-full text-xs">
                            <thead className="bg-secondary/30">
                              <tr>
                                {csvHeaders.map((h) => (
                                  <th
                                    key={h}
                                    className="px-2 py-1 text-left font-semibold border-b border-border"
                                  >
                                    {h}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {(() => {
                                const labelIdx = csvHeaders.findIndex(
                                  (h) =>
                                    h.trim().toLowerCase() ===
                                    "predicted_label",
                                );
                                const rows = csvRows
                                  .filter(
                                    (r) =>
                                      !filterText ||
                                      (labelIdx >= 0 &&
                                        (r[labelIdx] || "")
                                          .toLowerCase()
                                          .includes(filterText.toLowerCase())),
                                  )
                                  .slice(0, 100);
                                return rows.map((row, idx) => (
                                  <tr key={idx} className="odd:bg-card/30">
                                    {row.map((cell, cidx) => (
                                      <td
                                        key={cidx}
                                        className="px-2 py-1 border-b border-border whitespace-nowrap"
                                      >
                                        {cell}
                                      </td>
                                    ))}
                                  </tr>
                                ));
                              })()}
                            </tbody>
                          </table>
                        </div>
                        {csvRows.length > 100 && (
                          <div className="text-xs text-muted-foreground">
                            Showing first 100 rows of {csvRows.length}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </>
                )}

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <AlertCircle className="h-5 w-5" />
                      <span>Raw Response</span>
                    </CardTitle>
                    <CardDescription>
                      Response from prediction service
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <pre className="text-xs whitespace-pre-wrap break-all p-3 bg-card/50 rounded border border-border overflow-auto max-h-[32rem]">
                      {JSON.stringify(result, null, 2)}
                    </pre>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
