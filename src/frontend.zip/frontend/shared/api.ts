/**
 * Shared code between client and server
 * Types for network classification model API
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

/**
 * Network packet data structure
 */
export interface NetworkPacket {
  id: string;
  timestamp: number;
  source_ip: string;
  destination_ip: string;
  source_port: number;
  destination_port: number;
  protocol: string;
  packet_size: number;
  flags: string[];
  payload_size: number;
  flow_duration?: number;
  packets_per_second?: number;
  bytes_per_second?: number;
}

/**
 * Model classification result
 */
export interface ClassificationResult {
  packet_id: string;
  classification: string;
  confidence: number;
  timestamp: number;
  processing_time_ms: number;
  features_used: string[];
  threat_level: "low" | "medium" | "high" | "critical";
  details?: {
    predicted_class: string;
    probability_distribution: Record<string, number>;
    feature_importance?: Record<string, number>;
  };
}

/**
 * Real-time capture session status
 */
export interface CaptureSession {
  id: string;
  status: "idle" | "starting" | "capturing" | "stopping" | "error";
  interface: string;
  start_time?: number;
  packets_captured: number;
  packets_classified: number;
  error_message?: string;
}

/**
 * Model status and information
 */
export interface ModelStatus {
  loaded: boolean;
  model_name: string;
  version: string;
  last_updated: number;
  accuracy?: number;
  feature_count: number;
  supported_classes: string[];
  processing_time_avg_ms: number;
}

/**
 * Feature selection configuration
 */
export interface FeatureSelection {
  selected_features: string[];
  dropped_features: string[];
  total_features: number;
  selection_method: string;
  importance_scores?: Record<string, number>;
}

/**
 * Real-time statistics
 */
export interface NetworkStats {
  total_packets: number;
  packets_per_second: number;
  bytes_per_second: number;
  classification_breakdown: Record<string, number>;
  threat_level_breakdown: Record<string, number>;
  top_source_ips: Array<{ ip: string; count: number }>;
  top_destination_ips: Array<{ ip: string; count: number }>;
  protocol_breakdown: Record<string, number>;
}

/**
 * API Request/Response types
 */
export interface StartCaptureRequest {
  interface: string;
  filter?: string;
  max_packets?: number;
  duration_seconds?: number;
}

export interface StartCaptureResponse {
  session_id: string;
  status: string;
  message: string;
}

export interface StopCaptureRequest {
  session_id: string;
}

export interface StopCaptureResponse {
  session_id: string;
  status: string;
  final_stats: NetworkStats;
}

export interface GetModelStatusResponse {
  model: ModelStatus;
  feature_selection: FeatureSelection;
}

export interface GetRealtimeDataResponse {
  session: CaptureSession;
  recent_packets: NetworkPacket[];
  recent_classifications: ClassificationResult[];
  stats: NetworkStats;
}

export interface PredictFileResponse {
  source: string;
  endpoint: string;
  data: unknown;
}
