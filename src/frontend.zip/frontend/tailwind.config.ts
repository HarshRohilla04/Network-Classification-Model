import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./client/**/*.{ts,tsx}"],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
        // Network security themed colors
        security: {
          safe: "hsl(142 76% 36%)",
          "safe-foreground": "hsl(355 5% 95%)",
          warning: "hsl(45 93% 47%)",
          "warning-foreground": "hsl(26 83% 14%)",
          danger: "hsl(0 84% 60%)",
          "danger-foreground": "hsl(355 5% 95%)",
          critical: "hsl(348 83% 47%)",
          "critical-foreground": "hsl(355 5% 95%)",
        },
        cyber: {
          blue: "hsl(213 94% 68%)",
          "blue-dark": "hsl(213 94% 28%)",
          green: "hsl(142 69% 58%)",
          "green-dark": "hsl(142 69% 28%)",
          purple: "hsl(262 83% 58%)",
          "purple-dark": "hsl(262 83% 28%)",
          neon: "hsl(189 94% 43%)",
          "neon-dark": "hsl(189 94% 23%)",
        },
        threat: {
          low: "hsl(142 76% 36%)",
          medium: "hsl(45 93% 47%)",
          high: "hsl(25 95% 53%)",
          critical: "hsl(0 84% 60%)",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        mono: ["'JetBrains Mono'", "'Fira Code'", "Consolas", "monospace"],
        display: ["'Inter'", "system-ui", "sans-serif"],
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
        "pulse-glow": {
          "0%, 100%": {
            opacity: "1",
            transform: "scale(1)",
          },
          "50%": {
            opacity: "0.7",
            transform: "scale(1.05)",
          },
        },
        "scan-line": {
          "0%": {
            transform: "translateX(-100%)",
          },
          "100%": {
            transform: "translateX(100%)",
          },
        },
        "data-flow": {
          "0%": {
            transform: "translateY(100vh)",
            opacity: "0",
          },
          "10%": {
            opacity: "1",
          },
          "90%": {
            opacity: "1",
          },
          "100%": {
            transform: "translateY(-100vh)",
            opacity: "0",
          },
        },
        "network-pulse": {
          "0%, 100%": {
            transform: "scale(1)",
            opacity: "1",
          },
          "50%": {
            transform: "scale(1.1)",
            opacity: "0.8",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "pulse-glow": "pulse-glow 2s ease-in-out infinite",
        "scan-line": "scan-line 2s linear infinite",
        "data-flow": "data-flow 3s linear infinite",
        "network-pulse": "network-pulse 1.5s ease-in-out infinite",
      },
      backdropBlur: {
        xs: "2px",
      },
      boxShadow: {
        "glow-sm": "0 0 10px rgb(59 130 246 / 0.5)",
        "glow-md": "0 0 20px rgb(59 130 246 / 0.5)",
        "glow-lg": "0 0 30px rgb(59 130 246 / 0.5)",
        neon: "0 0 20px currentColor",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
